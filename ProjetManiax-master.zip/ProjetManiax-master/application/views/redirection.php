<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Acces interdit</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
</head>
<body><br><br><br><br>
<div class='container'>
    <div align='center'>
    <h1>Acces interdit</h1><br>
    <p>Cliquez ici pour vous connecter</p><br>
    <input class="btn btn-lg btn-danger btn-block" value="Se connecter" name="connexion" onclick="window.location.href='login_view'">
    </div>
</div>
</body>
</html>